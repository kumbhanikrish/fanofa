package com.example.task_interview

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
