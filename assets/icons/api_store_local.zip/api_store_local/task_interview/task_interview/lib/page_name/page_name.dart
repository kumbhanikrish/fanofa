
String studentListScreen = '/';
String updateStudentScreen = '/UpdateStudentScreen';

